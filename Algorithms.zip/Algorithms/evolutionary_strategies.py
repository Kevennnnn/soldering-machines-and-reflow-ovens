
import numpy as np

class Individual:
    def __init__(self, dimensions):
        self.solution = np.random.rand(dimensions)
        self.sigma = np.random.rand(dimensions)  # Mutation step size
        self.fitness = None

class EvolutionaryStrategy:
    def __init__(self, objective_func, dimensions, population_size, num_offspring, max_generations):
        self.objective_func = objective_func
        self.dimensions = dimensions
        self.population_size = population_size
        self.num_offspring = num_offspring
        self.max_generations = max_generations
        self.population = [Individual(dimensions) for _ in range(population_size)]

    def mutate(self, individual):
        # Mutate solution and sigma
        individual.sigma = np.exp(1/np.sqrt(self.dimensions+1)) * individual.sigma
        individual.solution += individual.sigma * np.random.randn(self.dimensions)
        return individual

    def recombine(self, parents):
        # Placeholder for recombination logic (could be discrete or intermediate recombination)
        child = Individual(self.dimensions)
        child.solution = np.mean([parent.solution for parent in parents], axis=0)
        child.sigma = np.mean([parent.sigma for parent in parents], axis=0)
        return child

    def select(self):
        # Placeholder for selection logic (e.g., (mu, lambda)-selection)
        self.population.sort(key=lambda ind: ind.fitness)
        self.population = self.population[:self.population_size]

    def evaluate(self, individual):
        individual.fitness = self.objective_func(individual.solution)
        return individual.fitness

    def run(self):
        for generation in range(self.max_generations):
            for individual in self.population:
                self.evaluate(individual)

            offspring = []
            for _ in range(self.num_offspring):
                parents = np.random.choice(self.population, 2)
                child = self.recombine(parents)
                child = self.mutate(child)
                child.fitness = self.evaluate(child)
                offspring.append(child)

            self.population.extend(offspring)
            self.select()

            best_individual = min(self.population, key=lambda ind: ind.fitness)
            print(f"Generation {generation + 1}: Best Fitness = {best_individual.fitness}")

def example_objective_function(solution):
    # Example objective function: minimize the sum of squares
    return np.sum(solution**2)

# Example usage
if __name__ == "__main__":
    dimensions = 10
    es = EvolutionaryStrategy(example_objective_function, dimensions, population_size=10, num_offspring=50, max_generations=100)
    es.run()
