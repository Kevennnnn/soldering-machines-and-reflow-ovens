
import numpy as np

def initial_solution():
    # Placeholder for initial solution generation
    return np.random.rand(10)

def neighbor(solution):
    # Generates a neighbor solution
    return solution + np.random.normal(0, 0.1, size=solution.shape)

def acceptance_probability(old_cost, new_cost, temperature):
    # Acceptance probability function for accepting new solutions
    if new_cost < old_cost:
        return 1.0
    else:
        return np.exp((old_cost - new_cost) / temperature)

def simulated_annealing(cost_func, initial_temperature, cooling_rate, max_iterations):
    current_solution = initial_solution()
    current_cost = cost_func(current_solution)
    best_solution = np.copy(current_solution)
    best_cost = current_cost
    
    temperature = initial_temperature
    
    for iteration in range(max_iterations):
        new_solution = neighbor(current_solution)
        new_cost = cost_func(new_solution)
        if acceptance_probability(current_cost, new_cost, temperature) > np.random.rand():
            current_solution = new_solution
            current_cost = new_cost
        
        if new_cost < best_cost:
            best_solution = np.copy(new_solution)
            best_cost = new_cost
        
        temperature *= cooling_rate
        print(f"Iteration {iteration + 1}: Best Cost = {best_cost}")
    
    return best_solution, best_cost

def example_cost_func(solution):
    # Example cost function
    return np.sum(solution**2)

# Example usage
if __name__ == "__main__":
    initial_temperature = 1000
    cooling_rate = 0.99
    max_iterations = 1000
    best_solution, best_cost = simulated_annealing(example_cost_func, initial_temperature, cooling_rate, max_iterations)
    print("Best Solution:", best_solution)
    print("Best Cost:", best_cost)
