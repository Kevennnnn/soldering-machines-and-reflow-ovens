
import numpy as np

class TabuSearch:
    def __init__(self, objective_func, initial_solution, tabu_size, max_iterations):
        self.objective_func = objective_func
        self.current_solution = initial_solution
        self.best_solution = initial_solution
        self.best_objective_value = self.objective_func(initial_solution)
        self.tabu_list = []
        self.tabu_size = tabu_size
        self.max_iterations = max_iterations

    def generate_neighbors(self, solution):
        # Placeholder for neighbor generation logic
        # This typically involves small perturbations in the solution
        neighbors = []
        for _ in range(5):  # Generate 5 neighbors as an example
            neighbor = solution + np.random.normal(0, 0.1, size=solution.shape)
            neighbors.append(neighbor)
        return neighbors

    def run(self):
        for iteration in range(self.max_iterations):
            neighbors = self.generate_neighbors(self.current_solution)
            best_neighbor = None
            best_neighbor_value = float('inf')

            for neighbor in neighbors:
                if list(neighbor) not in self.tabu_list and self.objective_func(neighbor) < best_neighbor_value:
                    best_neighbor = neighbor
                    best_neighbor_value = self.objective_func(neighbor)

            if best_neighbor is not None:
                self.current_solution = best_neighbor
                if best_neighbor_value < self.best_objective_value:
                    self.best_solution = best_neighbor
                    self.best_objective_value = best_neighbor_value

                self.tabu_list.append(list(self.current_solution))
                if len(self.tabu_list) > self.tabu_size:
                    self.tabu_list.pop(0)

            print(f"Iteration {iteration + 1}: Best Objective Value = {self.best_objective_value}")

def example_objective_function(solution):
    # Example objective function: minimize the sum of squares
    return np.sum(solution**2)

# Example usage
if __name__ == "__main__":
    initial_solution = np.random.rand(10)
    tabu_size = 5
    max_iterations = 100
    ts = TabuSearch(example_objective_function, initial_solution, tabu_size, max_iterations)
    ts.run()
