
import numpy as np

class Particle:
    def __init__(self, dimensions):
        self.position = np.random.rand(dimensions)
        self.velocity = np.random.rand(dimensions) - 0.5
        self.best_position = np.copy(self.position)
        self.best_value = float('inf')

class ParticleSwarmOptimization:
    def __init__(self, cost_func, dimensions, num_particles, max_iterations):
        self.cost_func = cost_func
        self.dimensions = dimensions
        self.num_particles = num_particles
        self.max_iterations = max_iterations
        self.global_best_position = None
        self.global_best_value = float('inf')
        self.particles = [Particle(dimensions) for _ in range(num_particles)]

    def optimize(self):
        for iteration in range(self.max_iterations):
            for particle in self.particles:
                value = self.cost_func(particle.position)
                if value < particle.best_value:
                    particle.best_value = value
                    particle.best_position = np.copy(particle.position)
                
                if value < self.global_best_value:
                    self.global_best_value = value
                    self.global_best_position = np.copy(particle.position)
            
            for particle in self.particles:
                cognitive_component = np.random.rand(self.dimensions) * (particle.best_position - particle.position)
                social_component = np.random.rand(self.dimensions) * (self.global_best_position - particle.position)
                particle.velocity = 0.5 * particle.velocity + cognitive_component + social_component
                particle.position += particle.velocity
            
            print(f"Iteration {iteration + 1}: Global Best Value = {self.global_best_value}")

def example_cost_func(position):
    return np.sum(position**2)

# Example usage
if __name__ == "__main__":
    dimensions = 5
    num_particles = 30
    max_iterations = 100
    pso = ParticleSwarmOptimization(example_cost_func, dimensions, num_particles, max_iterations)
    pso.optimize()
