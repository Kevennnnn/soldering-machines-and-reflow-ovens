
import numpy as np

class GeneticAlgorithm:
    def __init__(self, population_size, mutation_rate, crossover_rate, fitness_func):
        self.population_size = population_size
        self.mutation_rate = mutation_rate
        self.crossover_rate = crossover_rate
        self.fitness_func = fitness_func
        self.population = self.initialize_population()

    def initialize_population(self):
        # Placeholder for population initialization logic
        return np.random.rand(self.population_size)

    def calculate_fitness(self):
        fitness_scores = np.array([self.fitness_func(individual) for individual in self.population])
        return fitness_scores

    def select_parents(self, fitness_scores):
        # Placeholder for parent selection logic (e.g., roulette wheel, tournament)
        return np.random.choice(self.population, size=2, replace=False)

    def crossover(self, parent1, parent2):
        # Placeholder for crossover logic (e.g., single point, uniform)
        return (parent1 + parent2) / 2

    def mutate(self, individual):
        # Placeholder for mutation logic
        return individual + np.random.normal(0, 1, size=individual.shape)

    def run(self, generations):
        for generation in range(generations):
            fitness_scores = self.calculate_fitness()
            new_population = []
            for _ in range(self.population_size):
                parent1, parent2 = self.select_parents(fitness_scores)
                offspring = self.crossover(parent1, parent2)
                if np.random.rand() < self.mutation_rate:
                    offspring = self.mutate(offspring)
                new_population.append(offspring)
            self.population = np.array(new_population)
            print(f"Generation {generation + 1}: Best Fitness = {np.max(fitness_scores)}")

# Example usage
if __name__ == "__main__":
    def example_fitness_func(individual):
        # Placeholder for an example fitness function
        return -np.sum(individual**2)
    
    ga = GeneticAlgorithm(population_size=100, mutation_rate=0.01, crossover_rate=0.7, fitness_func=example_fitness_func)
    ga.run(generations=50)
