
import numpy as np

def objective_function(X):
    return np.sum(X**2, axis=1)

def initialize_alpha_beta_delta(pop_size, dim):
    alpha_pos = np.zeros(dim)
    beta_pos = np.zeros(dim)
    delta_pos = np.zeros(dim)
    alpha_score = float("inf")
    beta_score = float("inf")
    delta_score = float("inf")
    return alpha_pos, alpha_score, beta_pos, beta_score, delta_pos, delta_score

def update_position(X, alpha_pos, beta_pos, delta_pos, a):
    r1, r2 = np.random.rand(2)
    A1 = 2 * a * r1 - a
    C1 = 2 * r2
    D_alpha = np.abs(C1 * alpha_pos - X)
    X1 = alpha_pos - A1 * D_alpha

    r1, r2 = np.random.rand(2)
    A2 = 2 * a * r1 - a
    C2 = 2 * r2
    D_beta = np.abs(C2 * beta_pos - X)
    X2 = beta_pos - A2 * D_beta

    r1, r2 = np.random.rand(2)
    A3 = 2 * a * r1 - a
    C3 = 2 * r2
    D_delta = np.abs(C3 * delta_pos - X)
    X3 = delta_pos - A3 * D_delta

    return (X1 + X2 + X3) / 3

def grey_wolf_optimizer(obj_func, dim, wolf_num=20, iter_num=100):
    X = np.random.rand(wolf_num, dim)
    alpha_pos, alpha_score, beta_pos, beta_score, delta_pos, delta_score = initialize_alpha_beta_delta(wolf_num, dim)

    for i in range(iter_num):
        for j in range(wolf_num):
            fitness = obj_func(X[j, :])

            if fitness < alpha_score:
                alpha_score = fitness
                alpha_pos = X[j, :].copy()
            if fitness > alpha_score and fitness < beta_score:
                beta_score = fitness
                beta_pos = X[j, :].copy()
            if fitness > alpha_score and fitness > beta_score and fitness < delta_score:
                delta_score = fitness
                delta_pos = X[j, :].copy()

        a = 2 - i * (2 / iter_num)
        for j in range(wolf_num):
            X[j, :] = update_position(X[j, :], alpha_pos, beta_pos, delta_pos, a)

    return alpha_pos, alpha_score

# Example usage
dim = 5  # Dimension of the problem
wolf_num = 20  # Number of wolves
iter_num = 100  # Number of iterations
best_pos, best_score = grey_wolf_optimizer(objective_function, dim, wolf_num, iter_num)
print("Best Position:", best_pos)
print("Best Score:", best_score)
