
import numpy as np

class Ant:
    def __init__(self, alpha, beta, num_nodes, distances):
        self.alpha = alpha
        self.beta = beta
        self.num_nodes = num_nodes
        self.distances = distances
        self.tour = []
        self.distance = 0.0

    def find_tour(self, pheromone):
        self.tour = [np.random.randint(self.num_nodes)]
        while len(self.tour) < self.num_nodes:
            i = self.tour[-1]
            choices = [j if j not in self.tour else -1 for j in range(self.num_nodes)]
            probabilities = [
                (pheromone[i][j] ** self.alpha) * ((1.0 / self.distances[i][j]) ** self.beta) if j != -1 else 0
                for j in choices
            ]
            probabilities_sum = sum(probabilities)
            probabilities = [p / probabilities_sum for p in probabilities]
            next_city = np.random.choice(self.num_nodes, 1, p=probabilities)[0]
            self.tour.append(next_city)
            self.distance += self.distances[i][next_city]
        self.distance += self.distances[self.tour[-1]][self.tour[0]]

class ACO:
    def __init__(self, num_ants, num_iterations, alpha, beta, evaporation_rate, distances):
        self.num_ants = num_ants
        self.num_iterations = num_iterations
        self.alpha = alpha
        self.beta = beta
        self.evaporation_rate = evaporation_rate
        self.distances = distances
        self.pheromone = np.ones(distances.shape) / len(distances)
        self.best_distance = float('inf')
        self.best_tour = None

    def run(self):
        for iteration in range(self.num_iterations):
            ants = [Ant(self.alpha, self.beta, len(self.distances), self.distances) for _ in range(self.num_ants)]
            for ant in ants:
                ant.find_tour(self.pheromone)

                if ant.distance < self.best_distance:
                    self.best_distance = ant.distance
                    self.best_tour = ant.tour

            self.pheromone *= (1 - self.evaporation_rate)
            for ant in ants:
                for i, j in zip(ant.tour, ant.tour[1:] + [ant.tour[0]]):
                    self.pheromone[i][j] += 1.0 / ant.distance

            print(f"Iteration {iteration + 1}: Best Distance = {self.best_distance}")

# Example usage
if __name__ == "__main__":
    # Placeholder for distances matrix between nodes
    distances = np.random.rand(10, 10)
    distances = (distances + distances.T) / 2  # Make symmetric to represent distances
    np.fill_diagonal(distances, 0)  # Distance from a node to itself is 0

    aco = ACO(num_ants=10, num_iterations=100, alpha=1, beta=2, evaporation_rate=0.5, distances=distances)
    aco.run()
