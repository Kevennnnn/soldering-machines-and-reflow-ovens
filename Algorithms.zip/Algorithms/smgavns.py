
import numpy as np

# Helper Functions
def objective_function(vector):
    # Example objective function: Sphere function for minimization
    return sum(x**2 for x in vector)

def create_initial_population(pop_size, problem_size, bounds):
    return np.random.uniform(bounds[0], bounds[1], (pop_size, problem_size))

def evaluate_population(population):
    return np.array([objective_function(ind) for ind in population])

# Genetic Algorithm Operators
def select_parents(fitness):
    # Tournament selection
    winners = np.argsort(fitness)[:2]
    return winners

def crossover(parent1, parent2):
    alpha = np.random.uniform(0, 1)
    return alpha * parent1 + (1 - alpha) * parent2

def mutate(solution, mutation_rate, bounds):
    for i in range(len(solution)):
        if np.random.rand() < mutation_rate:
            solution[i] += np.random.uniform(-1, 1) * (bounds[1] - bounds[0]) * 0.1
    return np.clip(solution, bounds[0], bounds[1])

# VNS Operators
def shake(solution, k, bounds):
    neighbor = solution.copy()
    for _ in range(k):
        idx = np.random.randint(len(solution))
        neighbor[idx] += np.random.uniform(-1, 1) * (bounds[1] - bounds[0]) * 0.1
    return np.clip(neighbor, bounds[0], bounds[1])

def local_search(best_solution, bounds):
    # Implement a simple local search
    candidate = best_solution.copy()
    for i in range(len(best_solution)):
        candidate[i] += np.random.uniform(-1, 1) * (bounds[1] - bounds[0]) * 0.05
    if objective_function(candidate) < objective_function(best_solution):
        return candidate
    return best_solution

# SMGAVNS Core
def SMGAVNS(pop_size, problem_size, bounds, max_generations, mutation_rate):
    population = create_initial_population(pop_size, problem_size, bounds)
    best_solution = None
    best_fitness = float('inf')
    
    for generation in range(max_generations):
        fitness = evaluate_population(population)
        if min(fitness) < best_fitness:
            best_solution = population[np.argmin(fitness)]
            best_fitness = min(fitness)
        
        # GA Operations
        for i in range(pop_size // 2):
            parents_idx = select_parents(fitness)
            offspring = crossover(population[parents_idx[0]], population[parents_idx[1]])
            offspring = mutate(offspring, mutation_rate, bounds)
            population[i] = offspring
        
        # VNS Operations
        for i in range(pop_size):
            k_max = 5
            for k in range(1, k_max + 1):
                neighbor = shake(population[i], k, bounds)
                neighbor_fitness = objective_function(neighbor)
                if neighbor_fitness < fitness[i]:
                    population[i] = neighbor
                    fitness[i] = neighbor_fitness
                    break
        
        # Stratified Migration (simplified)
        if generation % 10 == 0:
            population = np.random.permutation(population)
        
        print(f"Generation {generation}, Best Fitness: {best_fitness}")
    
    return best_solution, best_fitness

# Parameters
pop_size = 50
problem_size = 5
bounds = (-5, 5)
max_generations = 50
mutation_rate = 0.1

# Running the algorithm
best_solution, best_fitness = SMGAVNS(pop_size, problem_size, bounds, max_generations, mutation_rate)
print("Best Solution:", best_solution)
print("Best Fitness:", best_fitness)
